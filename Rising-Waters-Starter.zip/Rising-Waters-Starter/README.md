# Rising Waters - Flood Prediction System

Rising Waters is a machine learning project that predicts flood risk using rainfall and weather-related features.

## Dataset

The project uses weather features such as:
- Temperature
- Humidity
- Cloud Cover
- Annual Rainfall
- June-September Rainfall
- River Level
- Pressure

Target column:
- Flood

## Project Workflow

1. Data Collection
2. Data Visualization and Analysis
3. Data Preprocessing
4. Model Building
5. Model Evaluation
6. Model Saving
7. Flask Application Development

## Technologies Used

Python, NumPy, Pandas, Matplotlib, Seaborn, Scikit-learn, XGBoost, Flask
